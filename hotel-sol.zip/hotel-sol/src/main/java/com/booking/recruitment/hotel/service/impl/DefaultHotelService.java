package com.booking.recruitment.hotel.service.impl;

import com.booking.recruitment.hotel.exception.BadRequestException;
import com.booking.recruitment.hotel.exception.ElementNotFoundException;
import com.booking.recruitment.hotel.model.Hotel;
import com.booking.recruitment.hotel.repository.HotelRepository;
import com.booking.recruitment.hotel.service.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
class DefaultHotelService implements HotelService {
  private final HotelRepository hotelRepository;

  @Autowired
  DefaultHotelService(HotelRepository hotelRepository) {
    this.hotelRepository = hotelRepository;
  }

  @Override
  public List<Hotel> getAllHotels() {
    return hotelRepository.findAll();
  }

  @Override
  public List<Hotel> getHotelsByCity(Long cityId) {
    return hotelRepository.findAll().stream()
        .filter((hotel) -> cityId.equals(hotel.getCity().getId()))
        .collect(Collectors.toList());
  }

  @Override
  public Hotel createNewHotel(Hotel hotel) {
    if (hotel.getId() != null) {
      throw new BadRequestException("The ID must not be provided when creating a new Hotel");
    }

    return hotelRepository.save(hotel);
  }

  @Override
  public Hotel getHotelById(Long hotelId) {
    return hotelRepository
            .findById(hotelId)
            .orElseThrow(() -> new ElementNotFoundException("Could not find hotel with ID provided"));
  }

  @Override
  public void deleteHotelById(Long hotelId) {
    Hotel hotel = getHotelById(hotelId);
    hotel.setDeleted(true);
    //hotelRepository.save(hotel);
    hotelRepository.delete(hotel);
  }


  @Override
  public List<Hotel> getAllHotelsByFilter(Long cityId, String sortBy) {
    List<Hotel> allHotels= getHotelsByCity(cityId);

    String distanceSortBy = "distance";

    if(distanceSortBy.equals(sortBy)){
      Collections.sort(allHotels, new Comparator<Hotel>() {
        @Override
        public int compare(Hotel o1, Hotel o2) {
          double distance = (haversine(o1.getCity().getCityCentreLatitude(),o1.getCity().getCityCentreLongitude(), o1.getLatitude(),o1.getLongitude())
                  -
                  haversine(o2.getCity().getCityCentreLatitude(),o2.getCity().getCityCentreLongitude(), o2.getLatitude(),o2.getLongitude())) * 100000;
          System.out.println("distance   for id "+ o1.getId()+ " ->"+ haversine(o1.getCity().getCityCentreLatitude(),o1.getCity().getCityCentreLongitude(), o1.getLatitude(),o1.getLongitude()));
          System.out.println("distance   for id "+ o2.getId()+" ->"+ haversine(o2.getCity().getCityCentreLatitude(),o2.getCity().getCityCentreLongitude(), o2.getLatitude(),o2.getLongitude()));
          return (int) distance;

        }
      });
    }


    return allHotels.stream().limit(3).collect(Collectors.toList());
  }

  static double haversine(double lat1, double lon1,
                          double lat2, double lon2) {
// distance between latitudes and longitudes
    double dLat = Math.toRadians(lat2 - lat1);
    double dLon = Math.toRadians(lon2 - lon1);

// convert to radians
    lat1 = Math.toRadians(lat1);
    lat2 = Math.toRadians(lat2);

// apply formulae
    double a = Math.pow(Math.sin(dLat / 2), 2) +
            Math.pow(Math.sin(dLon / 2), 2) *
                    Math.cos(lat1) *
                    Math.cos(lat2);
    double rad = 6371;
    double c = 2 * Math.asin(Math.sqrt(a));
    return rad * c;
  }
}
